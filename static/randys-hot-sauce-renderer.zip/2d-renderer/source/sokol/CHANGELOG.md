## CHANGELOG

> NOTE: this changelog is only for changes to the sokol-odin 'scaffolding'.
For actual Sokol header changes, see the
[sokol changelog](https://github.com/floooh/sokol/blob/master/CHANGELOG.md).

### 13-Apr-2024

Merged PR https://github.com/floooh/sokol-odin/pull/11, this changes the
directory structure of the bindings repository, adds support to build
the Windows bindings as a DLL and a couple of smaller things
detailed here: https://github.com/floooh/sokol/pull/1023
