#if defined(IMPL)
#define SOKOL_APP_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_app.h"
