#if defined(IMPL)
#define SOKOL_AUDIO_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_audio.h"

