#if defined(IMPL)
#define SOKOL_DEBUGTEXT_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_gfx.h"
#include "sokol_debugtext.h"

