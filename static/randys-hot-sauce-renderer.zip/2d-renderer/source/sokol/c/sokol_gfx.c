#if defined(IMPL)
#define SOKOL_GFX_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_gfx.h"
