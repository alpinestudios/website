#if defined(IMPL)
#define SOKOL_GL_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_gfx.h"
#include "sokol_gl.h"
