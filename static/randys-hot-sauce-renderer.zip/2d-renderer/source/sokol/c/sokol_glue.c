#if defined(IMPL)
#define SOKOL_GLUE_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_app.h"
#include "sokol_gfx.h"
#include "sokol_glue.h"
