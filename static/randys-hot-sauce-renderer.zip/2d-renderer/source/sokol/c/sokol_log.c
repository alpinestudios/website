#if defined(IMPL)
#define SOKOL_LOG_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_log.h"
