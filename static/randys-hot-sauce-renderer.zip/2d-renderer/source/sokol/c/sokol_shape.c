#if defined(IMPL)
#define SOKOL_SHAPE_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_gfx.h"
#include "sokol_shape.h"
