#if defined(IMPL)
#define SOKOL_TIME_IMPL
#endif
#include "sokol_defines.h"
#include "sokol_time.h"
